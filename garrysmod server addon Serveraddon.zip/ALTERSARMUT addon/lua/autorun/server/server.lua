math.randomseed(os.time())
mytable = {}
playernames = {}

-- percantages (added together 1. 1% = 1% = 100, 2. 2% + 1% = 3% = 300, 3. 2% + 2% + 1% = 5% = 500)
percantages = {1 ,41 , 52, 62, 740, 820, 900, 1000, 1010, 1100, 1200, 10000}

-- Creating a Randomnumber between 5000 and 50000
function randomstrength()
    function percantagecheck(randomnumber, number, percantage)
        if randomnumber < percantage then
            return (number+50)*100
        else 
            return 0;
        end
    end
    randomnumber = math.random(0,9999)
    for i=1,451,1 do
        number = 0
        number = percantagecheck(randomnumber, i, percantages[i])
        if number ~= 0 then
            return number
        end
    end
end

--Saving Data
function SaveStoreData(Data, path)
	local converted = util.TableToJSON(Data)
	file.Write(path, converted)
end

--Reading Data
function ReadStoreData(path)
	local JSONData = file.Read(path)
	return util.JSONToTable(JSONData)
end

--Player connect sequence
gameevent.Listen("player_connect")
hook.Add("player_connect", "Beitritt", function(data)
    if(file.Exists("strengthlist.json", "MOD")) then
        mytable = ReadStoreData("strengthlist.json")
    end
    if(file.Exists("playernames.json", "MOD")) then
        playernames = ReadStoreData("playernames.json")
    end
    playernames[data.networkid] = data.name
    playernames[data.name] = data.networkid
    SaveStoreData(playernames, "playernames.json")
    if mytable[data.networkid] == nil then
        mytable[data.networkid] = randomstrength()
        SaveStoreData(mytable, "strengthlist.json")
    end
end)

-- /strength command
gameevent.Listen("player_say")
hook.Add("PlayerSay", "strengthcommand", function(sender, text, teamChat)
    if( string.sub(text, 1, 9) == "/strength") then
        mytable = ReadStoreData("strengthlist.json")
        playernames = ReadStoreData("playernames.json")
        if mytable[string.sub(text, 11, -1)] ~= nil then
            sender:ChatPrint("Player "..playernames[string.sub(text, 11, -1)].." has a strength of "..mytable[string.sub(text, 11, -1)])
            return ""
        elseif mytable[playernames[string.sub(text, 11, -1)]] ~= nil then
            sender:ChatPrint("Player "..string.sub(text, 11, -1).." has a strength of "..mytable[playernames[string.sub(text, 11, -1)]])
            return ""
        else
            sender:ChatPrint("SteamID or username invalid (SteamID Format: STEAM_0:1:123456789)")
            return ""
        end
    end
end)